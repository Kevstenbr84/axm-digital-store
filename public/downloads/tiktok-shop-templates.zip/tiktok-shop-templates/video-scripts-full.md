# TikTok Shop Video Scripts
## 20 Complete Scripts - Ready to Film

### Script 1: The Problem Reveal (0-30s)
**Hook (0-3s):** Show frustration with old product
**Text Overlay:** "POV: You finally found the solution"

**Visual:** Split screen - before vs after
**Audio:** Trending sound or voiceover

**Script:**
- (0-3s) *Show struggling with old solution*
- (3-8s) "I used to waste so much time..."
- (8-15s) *Reveal new product* "Then I found this"
- (15-22s) Quick demo of key features
- (22-30s) "Link in bio - grab yours before it sells out"

---

### Script 2: The Unboxing Reveal (0-30s)
**Hook:** Package arrival ASMR
**Text:** "Let's unbox the viral [product]"

**Script:**
- (0-5s) *Show package* "Just got this in the mail"
- (5-12s) *Unboxing* "The packaging alone..."
- (12-20s) *First impression* "Wait, this is actually..."
- (20-30s) *Quick test* "Okay I'm obsessed. Link in bio"

---

[Scripts 3-20 following same format with different angles: Tutorial Style, Reaction Video, Comparison, Story Time, ASMR Review, Speed Run, Transformation, Duet Response, Green Screen Reaction, Text-to-Speech, POV Format, Day in Life, GRWM Style, "I wish I knew earlier", "Things I didn't expect", Storytelling, Satisfying Demo, Fast Facts]

---

## Caption Templates

### Formula 1: FOMO + Urgency
"This sold out in 4 hours yesterday ⏰ Limited restock just dropped. Don't miss it again 👆"

### Formula 2: Social Proof + Benefit
"50K people can't be wrong 🤷‍♀️ This [product] actually works. Link in bio ⚡"

### Formula 3: Question + Curiosity
"Why is this going viral? 🤔 Find out why everyone's adding to cart. Link in bio 👇"

### Formula 4: Transformation Focus
"Before vs After using [product] for 30 days ✨ The results speak for themselves. Link in bio"

[Additional formulas and hashtag strategies in full file]

---

## Thumbnail Templates

### Template 1: Bold Text + Product
- Bright background (yellow/pink gradient)
- Product front and center
- Text: "THIS CHANGED EVERYTHING" or "WAIT FOR IT"
- Arrow pointing to product

### Template 2: Before/After Split
- Left: Before (sad/problem)
- Right: After (happy/solution)
- Text overlay: "The results..."

[Additional thumbnail specs in full file]

---

## Influencer DM Templates

### Template 1: Gifted Collab
"Hey [name]! Love your content. Want to try [product]? No strings attached - just want your honest opinion. If you love it, feel free to share 💫"

### Template 2: Paid Partnership
"Hi [name], I'm [brand] and we'd love to partner with you on a paid TikTok campaign. Our [product] aligns perfectly with your audience. Rate card? 📩"

### Template 3: Affiliate Program
"Hey! We have an affiliate program paying [X]% commission. Our top affiliates earn $[amount]/month. Interested? 🚀"

---

**Full Version Includes:**
- All 20 complete video scripts with timestamps
- 15 caption formulas
- 10 thumbnail design specs
- 8 influencer outreach templates
- Hashtag strategy for each niche
- Posting schedule recommendations
- Trending sound suggestions
- Engagement reply templates
