# TikTok Shop Product Listing Templates
## 10 High-Converting Product Descriptions

### Template 1: The Problem-Solver
**For:** Problem-solving products

```
Title: [Product] - [Main Benefit] | Ships Fast

Description:
Tired of [problem]? Meet [product name] - the [category] that [main benefit].

✓ [Feature 1]
✓ [Feature 2]  
✓ [Feature 3]

⭐ 4.9/5 stars (2,000+ reviews)
🚚 Ships in 24 hours
💰 30-day guarantee

Tap "Add to Cart" now 👇
```

### Template 2: The Luxury Angle
**For:** Premium products

```
Title: Premium [Product] | [USP] | Limited Stock

Description:
Upgrade your [category] game with [product]. 

Crafted from [premium material]
Designed for [ideal customer]
[Number]-year warranty included

Only [number] left in stock.
Join 5,000+ happy customers.

Tap to shop now ⚡
```

### Template 3: The Social Proof Heavy
**For:** Products with strong reviews

```
Title: [Product] As Seen on TikTok 🔥 | [Price]

Description:
"This changed my life" - Sarah M.
"Best purchase I've made" - Mike T.
"Worth every penny" - Jessica L.

[Product] features:
• [Feature]
• [Feature]
• [Feature]

Over 10,000 sold in 30 days.
Free shipping on orders over $50.

Add to cart before we sell out 👆
```

[Additional templates 4-10 included in full version]

## Thumbnail Design Specs

### Design 1: Clean Product Focus
- Background: White or gradient
- Product: Centered, 80% of frame
- Text: Minimal, bold headline only
- Accent: Brand color border

### Design 2: Lifestyle Context
- Background: Real environment
- Product: Natural placement
- Text: "As Seen on TikTok" badge
- People: Using product

[Additional designs 3-10 in full version]

## Viral Caption Formulas

### Formula 1: Hook + Problem + Solution + CTA
"POV: You finally found [solution to problem] 🙌 This [product] changed everything. Link in bio!"

### Formula 2: Question + Curiosity + Urgency
"Why is everyone buying this [product]? 🤔 Find out why 50K people ordered yesterday. Link in bio before it sells out again!"

[Additional formulas in full version]

## Influencer Outreach Templates

### DM Template 1: First Contact
"Hey [Name]! Love your content on [topic]. I think my [product] would be perfect for your audience. Want to collab? I offer [commission%/free product/gifted]."

### Email Template 1: Professional
"Subject: Partnership Opportunity - [Product] for [Their Brand]

Hi [Name],

I'm [Your name] from [Brand]. I've been following your content and love your approach to [topic].

I think our [product] would resonate with your audience. Here's why:
- [Reason 1]
- [Reason 2]

Interested in a paid partnership? My rates are [details].

Best,
[Your name]"

[Additional outreach templates in full version]
