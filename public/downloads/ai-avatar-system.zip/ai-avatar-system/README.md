# AI Avatar/Headshot Generator
## Professional Portrait Prompts for Midjourney

## What's Inside

100+ Midjourney prompts organized by:
- **Business Professional** (20 prompts)
- **Creative Professional** (20 prompts)
- **Executive/Leadership** (20 prompts)
- **Casual/Approachable** (20 prompts)
- **Industry-Specific** (20 prompts)

## Bonus Content

- Lighting guide
- Pose reference directory
- Background collection
- Style variations

## Perfect For

- Personal branding
- LinkedIn profiles
- Company websites
- Marketing materials

## Pricing

Personal: $29 | Commercial: $49 | Agency: $149