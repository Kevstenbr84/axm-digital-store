# AI Avatar/Headshot Generator
## Midjourney Prompt Library for Professional Portraits

### Prompt Pack 1: Business Professional
```
Professional headshot of [man/woman], [age range], wearing [navy/burgundy/charcoal] [blazer/suit], confident smile, neutral gray studio background, soft professional lighting, corporate photography style, sharp focus, 8k resolution --ar 4:5 --v 6
```

### Prompt Pack 2: Creative Professional
```
Creative portrait of [man/woman], [age range], casual professional attire, artistic background, natural window light, editorial photography style, shallow depth of field, warm tones --ar 4:5 --v 6
```

### Prompt Pack 3: Executive/Leadership
```
Executive portrait, [man/woman], [age range], formal business attire, powerful stance, neutral background, dramatic side lighting, Fortune 500 style photography, ultra-sharp, cinematic --ar 4:5 --v 6
```

### Prompt Pack 4: Casual/Approachable
```
Friendly headshot of [man/woman], [age range], smart casual outfit, genuine smile, blurred office background, natural lighting, lifestyle photography, warm and approachable --ar 4:5 --v 6
```

### Prompt Pack 5: Industry-Specific
- Tech startup founder
- Medical professional
- Legal/Financial advisor
- Creative director
- Sales professional
- Academic/Professor
- Real estate agent
- Consultant

## Style Variations

### Lighting Styles
- Rembrandt lighting
- Butterfly lighting
- Split lighting
- Natural window light
- Studio flat light

### Background Options
- Gradient backgrounds
- Office environments
- Outdoor settings
- Abstract colors
- Textured walls

### Pose Directories
- 25 male poses
- 25 female poses
- 15 power poses
- 15 approachable poses

## Bonus: Avatar Generator Tool

### Description
A simple tool to customize prompts:
1. Select gender
2. Select age range
3. Select industry
4. Select style
5. Get optimized prompt

## Pricing & Usage

**Personal Use:** $29
**Commercial License:** $49
**Agency License:** $149

Includes:
- 100+ prompts
- Style guide
- Pose reference sheet
- Lighting guide
- Background collection